const big_image = document.getElementById("big").src;
        function mOver(event) {
            if (event.target.classList.contains("my-class")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big").src = small_image;
        }
        function mOut() {
            document.getElementById("big").src = big_image;
        }

        const big_image1 = document.getElementById("big1").src;
        function mOver1(event) {
            if (event.target.classList.contains("my-class1")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big1").src = small_image;
        }
        function mOut1() {
            document.getElementById("big1").src = big_image1;
        }

        const big_image2 = document.getElementById("big2").src;
        function mOver2(event) {
            if (event.target.classList.contains("my-class2")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big2").src = small_image;
        }
        function mOut2() {
            document.getElementById("big2").src = big_image2;
        }

        const big_image3 = document.getElementById("big3").src;
        function mOver3(event) {
            if (event.target.classList.contains("my-class3")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big3").src = small_image;
        }
        function mOut3() {
            document.getElementById("big3").src = big_image3;
        }

        const big_image4 = document.getElementById("big4").src;
        function mOver4(event) {
            if (event.target.classList.contains("my-class4")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big4").src = small_image;
        }
        function mOut4() {
            document.getElementById("big4").src = big_image4;
        }

        const big_image5 = document.getElementById("big5").src;
        function mOver5(event) {
            if (event.target.classList.contains("my-class5")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big5").src = small_image;
        }
        function mOut5() {
            document.getElementById("big5").src = big_image5;
        }

        const big_image6 = document.getElementById("big6").src;
        function mOver6(event) {
            if (event.target.classList.contains("my-class6")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big6").src = small_image;
        }
        function mOut6() {
            document.getElementById("big6").src = big_image6;
        }

        const big_image7 = document.getElementById("big7").src;
        function mOver7(event) {
            if (event.target.classList.contains("my-class7")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big7").src = small_image;
        }
        function mOut7() {
            document.getElementById("big7").src = big_image7;
        }

        const big_image8 = document.getElementById("big8").src;
        function mOver8(event) {
            if (event.target.classList.contains("my-class8")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big8").src = small_image;
        }
        function mOut8() {
            document.getElementById("big8").src = big_image8;
        }

        const big_image9 = document.getElementById("big9").src;
        function mOver9(event) {
            if (event.target.classList.contains("my-class9")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big9").src = small_image;
        }
        function mOut9() {
            document.getElementById("big9").src = big_image9;
        }

        const big_image10 = document.getElementById("big10").src;
        function mOver10(event) {
            if (event.target.classList.contains("my-class10")) {
            var small_image= event.target.src;
             } 
            document.getElementById("big10").src = small_image;
        }
        function mOut10() {
            document.getElementById("big10").src = big_image10;
        }